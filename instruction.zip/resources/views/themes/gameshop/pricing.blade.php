@extends($theme.'layouts.app')
@section('title',trans('About Us'))

@section('content')

     @include($theme.'sections.pricing')

@endsection
